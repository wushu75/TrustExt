/* TrustExt service worker (MV3).
   Intentionally minimal — the extension does its work in the popup and holds
   no background permissions. This worker only sets a sensible default language
   on first install and leaves clearly-marked hooks for future features. */

const STORAGE_KEY = "trustext_lang";

chrome.runtime.onInstalled.addListener(async (details) => {
  if (details.reason === "install") {
    try {
      const existing = await chrome.storage.local.get(STORAGE_KEY);
      if (!existing || !existing[STORAGE_KEY]) {
        const ui = (chrome.i18n.getUILanguage() || "en").toLowerCase();
        const lang = ui.startsWith("zh") ? "zh" : "en";
        await chrome.storage.local.set({ [STORAGE_KEY]: lang });
      }
    } catch (e) {
      // Storage may be unavailable in rare cases; the popup falls back gracefully.
      console.warn("TrustExt: could not set default language", e);
    }
  }
});

/* --------------------------------------------------------------------------
   ROADMAP HOOKS (not active in v1.0 — kept as documentation for contributors)

   1. Update checks for a self-hosted catalog:
        // const res = await fetch("https://<your-mirror>/catalog.json");
      Requires adding the host to host_permissions in manifest.json first.

   2. One-click CRX from mirrors + auto-update via update_url:
      This needs an "update_url" in manifest.json pointing at an updates.xml
      you host, plus signed CRX packages. Ship only from sources you control.

   3. Source-reputation signals (stars / last-commit) fetched from a mirror.
   -------------------------------------------------------------------------- */
