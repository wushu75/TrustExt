/* TrustExt popup logic — vanilla JS, no framework, MV3 CSP-safe (no inline handlers). */

/* ---- In-popup i18n dictionary --------------------------------------------
   chrome.i18n locale is fixed by the browser language, so the in-popup
   EN <-> 中文 toggle uses its own dictionary. Extension name/description in
   the browser UI still come from _locales/ via __MSG__ in the manifest.       */
const I18N = {
  en: {
    tagline: "Trusted open-source extensions without the blocked store",
    langToggle: "中文",
    searchPlaceholder: "Search extensions…",
    count: (n) => `${n} extensions`,
    sourceCta: "Source",
    verifyFlag: "Open source",
    securityNote:
      "Every extension here is open source — the full code is public, so you can verify it before installing. Always install from the official Source repository below.",
    repoLink: "Star on GitHub",
    emptyTitle: "No matches",
    emptySub: "Try a different name or category.",
    cats: {
      ads: "Privacy & Ads",
      appearance: "Appearance",
      productivity: "Productivity",
      security: "Security",
      developer: "Developer",
      translation: "Translation",
      media: "Media"
    }
  },
  zh: {
    tagline: "无需访问商店，安全安装开源扩展",
    langToggle: "EN",
    searchPlaceholder: "搜索扩展……",
    count: (n) => `共 ${n} 个扩展`,
    sourceCta: "源码",
    verifyFlag: "开源可验证",
    securityNote:
      "此处每个扩展均为开源项目，完整代码公开，安装前即可自行核验。请始终从下方官方「源码」仓库安装。",
    repoLink: "在 GitHub 点亮 Star",
    emptyTitle: "没有匹配结果",
    emptySub: "换个名称或分类试试。",
    cats: {
      ads: "隐私与广告",
      appearance: "外观",
      productivity: "效率",
      security: "安全",
      developer: "开发者",
      translation: "翻译",
      media: "媒体"
    }
  }
};

const STORAGE_KEY = "trustext_lang";
let lang = "en";

const $ = (sel) => document.querySelector(sel);
const listEl = $("#list");
const emptyEl = $("#empty");
const searchEl = $("#search");

/* Small inline SVGs reused per card (kept out of HTML to stay DRY). */
const SVG = {
  check:
    '<svg viewBox="0 0 24 24" width="11" height="11" fill="none"><path d="m5 12 4 4L19 7" stroke="currentColor" stroke-width="2.4" stroke-linecap="round" stroke-linejoin="round"/></svg>',
  arrow:
    '<svg viewBox="0 0 24 24" width="12" height="12" fill="none"><path d="M7 17 17 7M9 7h8v8" stroke="currentColor" stroke-width="1.8" stroke-linecap="round" stroke-linejoin="round"/></svg>'
};

function t() {
  return I18N[lang];
}

/* Apply static translations to any element tagged with data-i18n / data-i18n-attr. */
function applyStaticText() {
  const dict = t();
  document.documentElement.lang = lang === "zh" ? "zh-CN" : "en";

  document.querySelectorAll("[data-i18n]").forEach((el) => {
    const key = el.getAttribute("data-i18n");
    if (dict[key] != null) el.textContent = dict[key];
  });
  document.querySelectorAll("[data-i18n-attr]").forEach((el) => {
    const [attr, key] = el.getAttribute("data-i18n-attr").split("|");
    if (dict[key] != null) el.setAttribute(attr, dict[key]);
  });

  $("#langToggle").textContent = dict.langToggle;
}

/* Build one catalog card as an anchor so it opens the source with no permissions. */
function cardFor(ext) {
  const dict = t();
  const a = document.createElement("a");
  a.className = "card";
  a.href = ext.source;
  a.target = "_blank";
  a.rel = "noopener noreferrer";
  a.setAttribute("role", "listitem");

  a.innerHTML = `
    <div class="card-top">
      <div class="mono">${ext.name.charAt(0)}</div>
      <div class="card-main">
        <div class="card-head">
          <span class="card-name"></span>
          <span class="chip-cat"></span>
        </div>
        <p class="card-desc"></p>
      </div>
    </div>
    <div class="verify-row">
      <span class="verify-flag">${SVG.check}<span class="vf-text"></span></span>
      <span class="license"></span>
      <span class="source-cta"><span class="sc-text"></span>${SVG.arrow}</span>
    </div>`;

  a.querySelector(".card-name").textContent = ext.name;
  a.querySelector(".chip-cat").textContent = dict.cats[ext.cat] || ext.cat;
  a.querySelector(".card-desc").textContent = lang === "zh" ? ext.zh : ext.en;
  a.querySelector(".vf-text").textContent = dict.verifyFlag;
  a.querySelector(".license").textContent = ext.license;
  a.querySelector(".sc-text").textContent = dict.sourceCta;
  return a;
}

function render() {
  const catalog = window.TRUSTEXT_CATALOG || [];
  const q = searchEl.value.trim().toLowerCase();
  const dict = t();

  const filtered = catalog.filter((ext) => {
    if (!q) return true;
    const hay = [
      ext.name,
      ext.en,
      ext.zh,
      ext.license,
      dict.cats[ext.cat] || "",
      I18N.en.cats[ext.cat] || "",
      I18N.zh.cats[ext.cat] || ""
    ]
      .join(" ")
      .toLowerCase();
    return hay.includes(q);
  });

  listEl.innerHTML = "";
  filtered.forEach((ext) => listEl.appendChild(cardFor(ext)));

  const hasResults = filtered.length > 0;
  listEl.hidden = !hasResults;
  emptyEl.hidden = hasResults;
  $("#count").textContent = dict.count(filtered.length);
}

function setLang(next, persist = true) {
  lang = next === "zh" ? "zh" : "en";
  applyStaticText();
  render();
  if (persist && chrome?.storage?.local) {
    chrome.storage.local.set({ [STORAGE_KEY]: lang });
  }
}

/* Default language: stored choice -> browser UI language -> English. */
function initLang() {
  const guess = () => {
    const ui = (chrome?.i18n?.getUILanguage?.() || navigator.language || "en").toLowerCase();
    return ui.startsWith("zh") ? "zh" : "en";
  };
  if (chrome?.storage?.local) {
    chrome.storage.local.get(STORAGE_KEY, (res) => {
      setLang(res && res[STORAGE_KEY] ? res[STORAGE_KEY] : guess(), false);
    });
  } else {
    setLang(guess(), false);
  }
}

/* ---- Wire up ---- */
document.addEventListener("DOMContentLoaded", () => {
  $("#ver").textContent = chrome?.runtime?.getManifest?.().version || "1.0.0";
  $("#langToggle").addEventListener("click", () => setLang(lang === "en" ? "zh" : "en"));
  searchEl.addEventListener("input", render);
  initLang();
});
