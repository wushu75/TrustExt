/**
 * TrustExt curated catalog.
 * Every entry is a genuinely open-source project with a public source repository,
 * so users can verify the code themselves. Keep this list honest: only add
 * extensions whose full source is publicly available under an OSI license.
 *
 * Fields:
 *   id       stable slug (used for icons / keys)
 *   name     display name (not translated — these are proper nouns)
 *   cat      category key -> resolved via i18n (cat_*)
 *   license  SPDX identifier, shown verbatim
 *   source   canonical source repository (primary trust link)
 *   store    optional Chrome Web Store URL (secondary; may be blocked in CN)
 *   en / zh  one-line description in each language
 */
window.TRUSTEXT_CATALOG = [
  {
    id: "ublock-origin",
    name: "uBlock Origin",
    cat: "ads",
    license: "GPL-3.0",
    source: "https://github.com/gorhill/uBlock",
    store: "https://chromewebstore.google.com/detail/cjpalhdlnbpafiamejdnhcphjbkeiagm",
    en: "Efficient, wide-spectrum ad and tracker blocker that is light on memory and CPU.",
    zh: "高效的广告与追踪拦截器，占用内存和 CPU 极低。"
  },
  {
    id: "dark-reader",
    name: "Dark Reader",
    cat: "appearance",
    license: "MIT",
    source: "https://github.com/darkreader/darkreader",
    store: "https://chromewebstore.google.com/detail/eimadpbcbfnmbkopoojfekhnkhdbieeh",
    en: "Generates a comfortable dark mode for every website in real time.",
    zh: "为所有网站实时生成护眼的深色模式。"
  },
  {
    id: "stylus",
    name: "Stylus",
    cat: "appearance",
    license: "GPL-3.0",
    source: "https://github.com/openstyles/stylus",
    store: "https://chromewebstore.google.com/detail/clngdbkpkpeebahjckkjfobafhncgmne",
    en: "Install and write custom CSS themes to restyle any site you like.",
    zh: "安装或编写自定义 CSS 主题，随心重塑任意网站样式。"
  },
  {
    id: "violentmonkey",
    name: "Violentmonkey",
    cat: "productivity",
    license: "MIT",
    source: "https://github.com/violentmonkey/violentmonkey",
    store: "https://chromewebstore.google.com/detail/jinjaccalgkegednnccohejagnlnfdag",
    en: "Fully open-source userscript manager — the transparent alternative to Tampermonkey.",
    zh: "完全开源的用户脚本管理器 —— Tampermonkey 的透明开源替代品。"
  },
  {
    id: "bitwarden",
    name: "Bitwarden",
    cat: "security",
    license: "GPL-3.0",
    source: "https://github.com/bitwarden/clients",
    store: "https://chromewebstore.google.com/detail/nngceckbapebfimnlniiiahkandclblb",
    en: "Open-source password manager that stores logins in an encrypted vault.",
    zh: "开源密码管理器，将账号密码保存在加密保险库中。"
  },
  {
    id: "vimium",
    name: "Vimium",
    cat: "productivity",
    license: "MIT",
    source: "https://github.com/philc/vimium",
    store: "https://chromewebstore.google.com/detail/dbepggeogbaibhgnhhndojpepiihcmeb",
    en: "Navigate and control the browser entirely from the keyboard, Vim-style.",
    zh: "以 Vim 风格用键盘完全操控浏览器，无需鼠标。"
  },
  {
    id: "singlefile",
    name: "SingleFile",
    cat: "productivity",
    license: "AGPL-3.0",
    source: "https://github.com/gildas-lormeau/SingleFile",
    store: "https://chromewebstore.google.com/detail/mpiodijhokgodhhofbcjdecpffjipkle",
    en: "Save a complete web page — images and all — as one self-contained HTML file.",
    zh: "将完整网页（含图片）保存为单个自包含的 HTML 文件。"
  },
  {
    id: "sponsorblock",
    name: "SponsorBlock",
    cat: "media",
    license: "LGPL-3.0",
    source: "https://github.com/ajayyy/SponsorBlock",
    store: "https://chromewebstore.google.com/detail/mnjggcdmjocbbbhaepdhchncahnbgone",
    en: "Automatically skips sponsor segments and intros in YouTube videos.",
    zh: "自动跳过 YouTube 视频中的广告口播与片头片段。"
  },
  {
    id: "privacy-badger",
    name: "Privacy Badger",
    cat: "ads",
    license: "GPL-3.0",
    source: "https://github.com/EFForg/privacybadger",
    store: "https://chromewebstore.google.com/detail/pkehgijcmpdhfbdbbnkijodmdjhbjlgp",
    en: "Learns to block invisible trackers automatically. Built by the EFF.",
    zh: "由 EFF 出品，自动学习并拦截隐形追踪器。"
  },
  {
    id: "simple-translate",
    name: "Simple Translate",
    cat: "translation",
    license: "MIT",
    source: "https://github.com/sienori/simple-translate",
    store: "https://chromewebstore.google.com/detail/ibplnjkanclpjokhdolnendpplpjiace",
    en: "Translate selected text or the whole page in place, without leaving the tab.",
    zh: "在当前页面就地翻译选中文字或整页内容，无需跳转。"
  },
  {
    id: "refined-github",
    name: "Refined GitHub",
    cat: "developer",
    license: "MIT",
    source: "https://github.com/refined-github/refined-github",
    store: "https://chromewebstore.google.com/detail/hlepfoohegkhhmjieoechaddaejaokhf",
    en: "Dozens of quality-of-life improvements for the GitHub interface.",
    zh: "为 GitHub 界面带来数十项使用体验优化。"
  },
  {
    id: "ublacklist",
    name: "uBlacklist",
    cat: "developer",
    license: "MPL-2.0",
    source: "https://github.com/iorate/uBlacklist",
    store: "https://chromewebstore.google.com/detail/pncfbmialoiaghdehhbnbhkkgmjanfhe",
    en: "Blocks low-quality and content-farm sites from your search results.",
    zh: "从搜索结果中屏蔽低质量网站与内容农场（如镜像站、采集站）。"
  }
];
